// package com.mall.mall.controllers;

// import java.util.List;
// import java.util.Optional;

// import org.springframework.beans.factory.annotation.Autowired;

// import org.springframework.web.bind.annotation.DeleteMapping;
// import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.PathVariable;
// import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.PutMapping;
// import org.springframework.web.bind.annotation.RequestBody;
// import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RestController;

// import com.mall.mall.models.Payment;
// import com.mall.mall.repositories.PaymentRepository;

// @RestController
// @RequestMapping(path="api/mall/")
// public class PaymentController {
// 	@Autowired
// 	private PaymentRepository paymentrepository;
	
// 	PaymentController(PaymentRepository paymentrepository){
// 		this.paymentrepository=paymentrepository;
// 	}
	
	
// 	@GetMapping("/payments")
// 	public List<Payment> getAllPayment(){
// 		return (List<Payment>) paymentrepository.findAll();
		
// 	}
	
	
	
// 	@PostMapping(value="payment")
// 	public Payment payment(@RequestBody Payment paymentobj ) {
// 		return paymentrepository.save(paymentobj);
// 	}
	
// 	@GetMapping("/{payment_id}")
// 	public Optional<Payment> getPaymentbyId(@PathVariable Long payment_id){
// 		return paymentrepository.findById(payment_id);
// 	}
	
// 	@PutMapping("/payments/{payment_id}")
// 	public Payment replacePayment(@RequestBody Payment newPayment, @PathVariable Long payment_id) {
// 		return paymentrepository.save(newPayment);
// 	}
	
// 	@DeleteMapping("/delete_payment/{payment_id}")
// 	void deletePayment(@PathVariable Long payment_id) {
// 		paymentrepository.deleteById(payment_id);
		
// 	}

// }
