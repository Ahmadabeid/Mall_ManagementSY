package com.mall.mall.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mall.mall.models.Floor;

@Repository
public interface FloorRepository extends CrudRepository<Floor,Long>{

}
