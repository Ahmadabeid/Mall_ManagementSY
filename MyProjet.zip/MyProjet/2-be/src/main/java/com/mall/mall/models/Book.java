package com.mall.mall.models;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "book")
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long book_id;
    private Date date;
    private String type;
    
    
    @ManyToOne
    private Slot slot;
    
    
    

    public Slot getSlot() {
		return slot;
	}

	public void setSlot(Slot slot) {
		this.slot = slot;
	}
	
	
	
	/**BOOK  */
	
	 @ManyToOne
	    private Payment payment;	
	
	 
	public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}

	/** */
	
	
	/** VENDOR */
	
	 @ManyToOne
	    private Vendor vendor;
	  

	   
	
	public Vendor getVendor() {
		return vendor;
	}

	public void setVendor(Vendor vendor) {
		this.vendor = vendor;
	}

	/** */

	public Book() {
    }

	public Long getBook_id() {
		return book_id;
	}

	public void setBook_id(Long book_id) {
		this.book_id = book_id;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Book(Long book_id, Date date, String type) {
		super();
		this.book_id = book_id;
		this.date = date;
		this.type = type;
	}

	

	

    
    



    

    
    
}
