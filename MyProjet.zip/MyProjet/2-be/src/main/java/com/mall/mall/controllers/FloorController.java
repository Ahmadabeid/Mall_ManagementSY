// package com.mall.mall.controllers;

// import java.util.Optional;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.web.bind.annotation.DeleteMapping;
// import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.PathVariable;
// import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.PutMapping;
// import org.springframework.web.bind.annotation.RequestBody;
// import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RestController;

// import com.mall.mall.models.Floor;
// import com.mall.mall.repositories.FloorRepository;

// @RestController
// @RequestMapping(path="api/mall/")
// public class FloorController {
// 	@Autowired
// 	private FloorRepository floorRepository;
	
// 	@PostMapping(value="save")
// 	public Floor postFloor(@RequestBody Floor floorobj) {
// 		return floorRepository.save(floorobj);
		
// 	}
	
// 	@GetMapping("/{floor_id}")
// 	public Optional<Floor> getFloorbyId(@PathVariable Long floor_id){
// 		return floorRepository.findById(floor_id);
// 	}
	
// 	@PutMapping("/floor/{floor_id}")
// 	public Floor replaceFloor(@RequestBody Floor newFloor, @PathVariable Long floor_id) {
// 		return floorRepository.save(newFloor);
// 	}
	
// 	@DeleteMapping("/delete_floor/{floor_id}")
// 	void deleteFloor(@PathVariable Long floor_id) {
// 		floorRepository.deleteById(floor_id);
		
// 	}


// }
