package com.mall.mall.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.mall.mall.models.Slot;
import com.mall.mall.repositories.SlotRepository;

@RestController
@RequestMapping(path="api/mall/slots")
@CrossOrigin(origins = "*")
public class SlotController {
	
	@Autowired
	private SlotRepository slotRepository;
	
	@PostMapping(value="")
	public Slot postslot(@RequestBody Slot slotobj ){
		return slotRepository.save(slotobj);
		
	}
	@GetMapping("/{id}")
	public Optional<Slot> getSlottbyId(@PathVariable Long id){
		return slotRepository.findById(id);
	}
	
	@PutMapping("")
	public Slot replaceSlot(@RequestBody Slot newSlot) {
		return slotRepository.save(newSlot);
	}
	
	@DeleteMapping("/{id}")
	void deleteSlot(@PathVariable Long id) {
		slotRepository.deleteById(id);
	}	

	@GetMapping("")
	public List<Slot> getAllSlots(){
		return slotRepository.findAll();
	}

}
