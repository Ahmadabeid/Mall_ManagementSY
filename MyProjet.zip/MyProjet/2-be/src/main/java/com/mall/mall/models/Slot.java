package com.mall.mall.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Slot {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long slot_id;
    private int s_size;
    private int s_width;
    private String s_name;

//    @ManyToOne
//    private Floor floor;

    

//    public Floor getFloor() {
//        return floor;
//    }
//
//    public void setFloor(Floor floor) {
//        this.floor = floor;
//    }

	public Slot() {
		super();
	}

	public Slot(Long slot_id, int s_size, int s_width, String s_name, Floor floor) {
		super();
		this.slot_id = slot_id;
		this.s_size = s_size;
		this.s_width = s_width;
		this.s_name = s_name;
//		this.floor = floor;
	}

	public Long getSlot_id() {
		return slot_id;
	}

	public void setSlot_id(Long slot_id) {
		this.slot_id = slot_id;
	}

	public int getS_size() {
		return s_size;
	}

	public void setS_size(int s_size) {
		this.s_size = s_size;
	}

	public int getS_width() {
		return s_width;
	}

	public void setS_width(int s_width) {
		this.s_width = s_width;
	}

	public String getS_name() {
		return s_name;
	}

	public void setS_name(String s_name) {
		this.s_name = s_name;
	}

   
     

    }
