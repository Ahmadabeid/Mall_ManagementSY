// package com.mall.mall.controllers;

// import java.util.Optional;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.web.bind.annotation.DeleteMapping;
// import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.PathVariable;
// import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.PutMapping;
// import org.springframework.web.bind.annotation.RequestBody;
// import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RestController;

// import com.mall.mall.models.Book;
// import com.mall.mall.repositories.BookRepository;


// @RestController
// @RequestMapping(path="api/mall/")
// public class BookController {
	
	
// 	@Autowired
// 	private BookRepository bookRepository;
	
	
// 	@PostMapping(value="book")
// 	public Book postbook(@RequestBody Book bookobj) {
// 		return bookRepository.save(bookobj);
		
// 	}
	
// 	@GetMapping("/{book}")
// 	public Optional<Book> getBookbyId(@PathVariable Long book_id){
// 		return bookRepository.findById(book_id);
// 	}
	
// 	@PutMapping("/book/{book_id}")
// 	public Book replacebook(@RequestBody Book newBook, @PathVariable Long book_id) {
// 		return bookRepository.save(newBook);
// 	}
	
// 	@DeleteMapping("/delete_payment/{payment_id}")
// 	void deletePayment(@PathVariable Long book_id) {
// 		bookRepository.deleteById(book_id);
		
// 	}

	
	
	

// }
