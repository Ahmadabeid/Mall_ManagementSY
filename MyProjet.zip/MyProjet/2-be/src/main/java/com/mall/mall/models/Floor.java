package com.mall.mall.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "floor")
public class Floor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long floor_id;
    private Long no;
    private String block_no;
    
    
	public Long getFloor_id() {
		return floor_id;
	}
	public void setFloor_id(Long floor_id) {
		this.floor_id = floor_id;
	}
	public Long getNo() {
		return no;
	}
	public void setNo(Long no) {
		this.no = no;
	}
	public String getBlock_no() {
		return block_no;
	}
	public void setBlock_no(String block_no) {
		this.block_no = block_no;
	}
	public Floor(Long floor_id, Long no, String block_no) {
		super();
		this.floor_id = floor_id;
		this.no = no;
		this.block_no = block_no;
	}
	public Floor() {
		super();
	}


   







    
    


    
    
}
