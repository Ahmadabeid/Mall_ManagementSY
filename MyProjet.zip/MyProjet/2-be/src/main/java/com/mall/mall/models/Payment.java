package com.mall.mall.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "payment")
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long paymen_id;
    private int amount;
    private String name;
	public Payment() {
		super();
	}
	public Payment(Long paymen_id, int amount, String name) {
		super();
		this.paymen_id = paymen_id;
		this.amount = amount;
		this.name = name;
	}
	public Long getPaymen_id() {
		return paymen_id;
	}
	public void setPaymen_id(Long paymen_id) {
		this.paymen_id = paymen_id;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

   


    

    

    
    
    
}
