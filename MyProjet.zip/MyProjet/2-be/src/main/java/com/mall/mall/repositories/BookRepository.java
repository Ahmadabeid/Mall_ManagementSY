package com.mall.mall.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mall.mall.models.Book;

@Repository
public interface BookRepository extends CrudRepository<Book,Long>  {

}
