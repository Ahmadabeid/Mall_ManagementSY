package com.mall.mall.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mall.mall.models.Vendor;

@Repository
public interface VendorRepository extends CrudRepository<Vendor,Long> {


}
