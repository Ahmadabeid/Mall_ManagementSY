export interface Slot {
    id: number;
    name: string;   
}