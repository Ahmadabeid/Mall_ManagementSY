import { ActivatedRoute } from '@angular/router';
import { Component, Input, OnInit } from '@angular/core';
import { Location } from '@angular/common';

import { SlotService } from '../slot.service';
import { Slot } from '../slot';

@Component({
  selector: 'app-slot-detail',
  templateUrl: './slot-detail.component.html',
  styleUrls: ['./slot-detail.component.css']
})
export class SlotDetailComponent implements OnInit {

  @Input() slot?: Slot;

  constructor(
    private route: ActivatedRoute,
    private slotService: SlotService,
    private location: Location
  ) { }

  ngOnInit(): void {
    this.getSlot();
  }

  getSlot(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.slotService.getSlot(id)
      .subscribe(slot => this.slot = slot);
  }

  goBack(): void {
    this.location.back();
  }

  update(): void{
    if(this.slot) {
      this.slotService.updateSlot(this.slot)
        .subscribe(() => this.goBack());
    }
  }
}
