import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
import { Slot } from './slot';

@Injectable({
  providedIn: 'root',
})
export class InMemoryDataService implements InMemoryDataService {
  createDb() {
    const slots = [
      { id: 12, name: 'Cloth Shop' },
      { id: 13, name: 'Computer Shop' },
      { id: 14, name: 'Electronics Shop' },
      { id: 15, name: 'Furniture Shop' },
      { id: 16, name: 'Grocery Shop' },
      { id: 17, name: 'Hardware Shop' },
      { id: 18, name: 'Jewelry Shop' },
      { id: 19, name: 'Laptop Shop' },
      { id: 20, name: 'Mobile Shop' },
    ];
    return {slots};
  }

  genId(slots: Slot[]): number {
    return slots.length > 0 ? Math.max(...slots.map(slot => slot.id)) + 1 : 11;
  }
}