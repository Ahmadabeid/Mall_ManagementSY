import { catchError, map, tap } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Slot } from './slot';
import { SLOTS } from './mock-slots';

@Injectable({
  providedIn: 'root',
})
export class SlotService {
  private slotsUrl = 'api/slots';
  // private slotsUrl = 'http://localhost:8080/api/mall/slots'

  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
  };

  constructor(private http: HttpClient) {}

  /** GET slots from the server */
  getSlots(): Observable<Slot[]> {
    return this.http.get<Slot[]>(this.slotsUrl);
  }

  /** GET hero by id. */
  getSlot(id: number): Observable<Slot> {
    const url = `${this.slotsUrl}/${id}`;
    return this.http.get<Slot>(url);
  }

  /** POST: add a new slot to the server */
  addSlot(slot: Slot): Observable<Slot> {
    return this.http.post<Slot>(this.slotsUrl, slot, this.httpOptions);
  }

  /** PUT: update the slot on the server */
  updateSlot(slot: Slot): Observable<any> {
    return this.http.put(this.slotsUrl, slot, this.httpOptions);
  }

  /** DELETE: delete the slot from the server */
  deleteSlot(id: number): Observable<Slot> {
    const url = '${this.slotsUrl}/${id}';
    return this.http.delete<Slot>(url, this.httpOptions);
  }
}
