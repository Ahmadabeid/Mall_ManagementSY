import { Component, OnInit } from '@angular/core';
import { SLOTS } from '../mock-slots'
import { Slot } from '../slot';
import { SlotService } from '../slot.service';

@Component({
  selector: 'app-slots',
  templateUrl: './slots.component.html',
  styleUrls: ['./slots.component.css']
})
export class SlotsComponent implements OnInit {

  slots: Slot[] = [];
  selectedSlot?: Slot;

  constructor(private slotService: SlotService) { }

  ngOnInit(): void {
    this.getSlots();
  }

  getSlots(): void {
    this.slotService.getSlots()
      .subscribe(slots => this.slots = slots);
  }

  add(name: string): void {
    name = name.trim();
    if (!name) { return; }
    this.slotService.addSlot({ name } as Slot)
      .subscribe(slot => {
        this.slots.push(slot);
      });
  }

  delete(slot: Slot): void {
    this.slots = this.slots.filter(s => s !== slot);
    this.slotService.deleteSlot(slot.id).subscribe();
  }
}
