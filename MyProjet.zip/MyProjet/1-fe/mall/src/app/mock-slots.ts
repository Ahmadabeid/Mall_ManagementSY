import { Slot } from "./slot";

export const SLOTS: Slot[] = [
    { id: 12, name: "Cloth Shop" },
    { id: 13, name: "Computer Shop" },
    { id: 14, name: "Electronics Shop" },
    { id: 15, name: "Furniture Shop" },
    { id: 16, name: "Grocery Shop" },
    { id: 17, name: "Hardware Shop" },
    { id: 18, name: "Jewelry Shop" },
    { id: 19, name: "Laptop Shop" },
    { id: 20, name: "Mobile Shop" },
];